// src/pages/ClientDetails.js
import React from 'react';
import { useParams } from 'react-router-dom';
import { Table, Icon } from 'semantic-ui-react';
import './ClientDetails.css'; // Custom CSS for styling

const ClientDetails = () => {
  const { clientId, projectId } = useParams(); // Get clientId and projectId from the URL

  // Complete mock data for employees by client project
  const employeesData = {
    'acme-corp': {
      'website-redesign': [
        { name: 'John Doe', role: 'Frontend Developer', status: 'Active' },
        { name: 'Jane Smith', role: 'Backend Developer', status: 'Active' },
      ],
      'mobile-app-development': [
        { name: 'Alice Johnson', role: 'Mobile Developer', status: 'On Leave' },
        { name: 'Bob Brown', role: 'QA Engineer', status: 'Active' },
      ],
    },
    'global-tech': {
      'ai-research': [
        { name: 'Charlie Wilson', role: 'AI Scientist', status: 'Active' },
        { name: 'Daisy Thomas', role: 'Data Analyst', status: 'Active' },
      ],
      'data-migration': [
        { name: 'Evelyn White', role: 'Data Engineer', status: 'Active' },
        { name: 'Frank Green', role: 'Database Admin', status: 'Active' },
        { name: 'George Adams', role: 'Migration Specialist', status: 'Active' },
      ],
    },
    'healthify-inc': {
      'health-tracking-app': [
        { name: 'Grace Lee', role: 'App Developer', status: 'Active' },
        { name: 'Henry Baker', role: 'Healthcare Specialist', status: 'On Leave' },
      ],
      'wellness-portal': [
        { name: 'Isla Moore', role: 'Frontend Developer', status: 'Active' },
        { name: 'Jack Turner', role: 'Backend Developer', status: 'Active' },
        { name: 'Kara Reed', role: 'Wellness Coordinator', status: 'Active' },
      ],
    },
    'edupro': {
      'e-learning-platform': [
        { name: 'Liam Brown', role: 'Content Developer', status: 'Active' },
        { name: 'Mia Williams', role: 'Instructional Designer', status: 'Active' },
      ],
      'course-management-system': [
        { name: 'Noah Davis', role: 'System Admin', status: 'Active' },
        { name: 'Olivia Wilson', role: 'Developer', status: 'Active' },
        { name: 'Paul Adams', role: 'Course Manager', status: 'Active' },
      ],
    },
  };

  const clientName = clientId.replace('-', ' ').replace(/\b\w/g, (char) => char.toUpperCase());
  const projectName = projectId.replace('-', ' ').replace(/\b\w/g, (char) => char.toUpperCase());
  const employees = (employeesData[clientId] && employeesData[clientId][projectId]) || []; // Get employees for the current project under the current client

  return (
    <div className="client-details-container">
      <h2>{`Employees for ${projectName} at ${clientName}`}</h2>
      <Table celled padded className="employee-table">
        <Table.Header>
          <Table.Row>
            <Table.HeaderCell>Employee Name</Table.HeaderCell>
            <Table.HeaderCell>Role</Table.HeaderCell>
            <Table.HeaderCell>Status</Table.HeaderCell>
          </Table.Row>
        </Table.Header>

        <Table.Body>
          {employees.map((employee, index) => (
            <Table.Row key={index}>
              <Table.Cell>
                <Icon name="user" /> {employee.name}
              </Table.Cell>
              <Table.Cell>{employee.role}</Table.Cell>
              <Table.Cell>{employee.status}</Table.Cell>
            </Table.Row>
          ))}
        </Table.Body>
      </Table>
    </div>
  );
};

export default ClientDetails;
