// src/App.js
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom'; // Updated imports
import Navbar from './components/Navbar'; // Import the new Sidebar Navbar
import Dashboard from './pages/Dashboard'; // Your main content components
import Projects from './pages/Projects'; // Example of another route/page
import ClientDetails from './pages/ClientDetails'; // New client details page
import ClientProjects from './pages/ClientProjects'; // New client projects page
import ProjectEmployees from './pages/ProjectEmployees'; // New project employees page
import './App.css'; // Import general styles

const App = () => {
  return (
    <Router>
      <div className="app-container">
        <Navbar />
        <div className="content-container">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/projects" element={<Projects />} />
            <Route path="/client/:clientId" element={<ClientDetails />} /> {/* New Route for Client Details */}
            <Route path="/client/:clientId/projects" element={<ClientProjects />} /> {/* Route for Client Projects */}
            <Route path="/client/:clientId/project/:projectId" element={<ProjectEmployees />} /> {/* Route for Project Employees */}
          </Routes>
        </div>
      </div>
    </Router>
  );
};

export default App;
