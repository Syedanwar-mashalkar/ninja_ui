// src/components/Navbar.js
import React from 'react';
import { Menu } from 'semantic-ui-react';
import { Link, useLocation } from 'react-router-dom';
import './Navbar.css'; // Import the CSS for navbar styling
import logo from '../assets/images/logo.png'; // Adjusted path to logo.png

const Navbar = () => {
  const location = useLocation();
  const activeItem = location.pathname;

  return (
    <div className="sidebar">
      {/* Add the logo at the top of the sidebar */}
      <div className="logo-container">
        <img src={logo} alt="Platform X Logo" className="navbar-logo" />
      </div>
      <Menu vertical pointing secondary className="navbar-menu">
        <Menu.Item
          name="dashboard"
          active={activeItem === '/'}
          as={Link}
          to="/"
          className="item"
        >
          Dashboard
        </Menu.Item>
        <Menu.Item
          name="projects"
          active={activeItem === '/projects'}
          as={Link}
          to="/projects"
          className="item"
        >
          Projects
        </Menu.Item>
      </Menu>
    </div>
  );
};

export default Navbar;
